<html>
<head>
    <script type="text/javascript" src="client.js"></script>
</head>
<body>

    <form id="date">
    <input type="text" id="startDate" placeholder="YYYY-MM-DD"></input><br/>
    <input type="text" id="endDate" placeholder="YYYY-MM-DD"></input><br/>
    <input type="button" value="Submit" onclick="process();"></input>
    </form>

    <div id="serverOutput" />

</body>
</html>
