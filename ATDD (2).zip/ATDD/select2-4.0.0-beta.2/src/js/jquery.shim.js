define(function () {
    return jQuery;
});
